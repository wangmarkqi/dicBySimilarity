from .dicBySimilarity import SimiDic
